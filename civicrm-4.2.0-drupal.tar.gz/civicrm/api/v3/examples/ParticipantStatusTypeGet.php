<?php



/*
 
 */
function participant_status_type_get_example(){
$params = array( 
  'version' => 3,
  'name' => 'test status',
  'label' => 'I am a test',
  'class' => 'Positive',
  'is_reserved' => 0,
  'is_active' => 1,
  'is_counted' => 1,
  'visibility_id' => 1,
  'weight' => 10,
);

  require_once 'api/api.php';
  $result = civicrm_api( 'participant_status_type','get',$params );

  return $result;
}

/*
 * Function returns array of result expected from previous function
 */
function participant_status_type_get_expectedresult(){

  $expectedResult = array( 
  'is_error' => 0,
  'version' => 3,
  'count' => 1,
  'id' => 14,
  'values' => array( 
      '14' => array( 
          'id' => '14',
          'name' => 'test status',
          'label' => 'I am a test',
          'class' => 'Positive',
          'is_reserved' => 0,
          'is_active' => '1',
          'is_counted' => '1',
          'weight' => '10',
          'visibility_id' => '1',
        ),
    ),
);

  return $expectedResult  ;
}




/*
* This example has been generated from the API test suite. The test that created it is called
* 
* testGetParticipantStatusType and can be found in 
* http://svn.civicrm.org/civicrm/branches/v3.4/tests/phpunit/CiviTest/api/v3/ParticipantStatusTypeTest.php
* 
* You can see the outcome of the API tests at 
* http://tests.dev.civicrm.org/trunk/results-api_v3
* and review the wiki at
* http://wiki.civicrm.org/confluence/display/CRMDOC/CiviCRM+Public+APIs
* Read more about testing here
* http://wiki.civicrm.org/confluence/display/CRM/Testing
*/